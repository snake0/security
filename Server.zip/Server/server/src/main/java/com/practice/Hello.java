package com.practice;
import java.io.*;
import java.util.*;

public class Hello {
    private final long id;
    private final String begin;
    private final String end;
    private final String ladder;
    public long getId() {
        return id;
    }
    public String getBegin() {
        return begin;
    }
    public String getEnd() {
        return end;
    }
    public String getLadder() {
        return ladder;
    }
    public Hello(long id, String begin, String end) {
        this.id = id;
        this.begin = begin;
        this.end = end;
        this.ladder = ladder(begin,end);
    }
    public boolean setUpDic(HashSet<String> dic) {
        try {
            File file = new File("C:\\Users\\lenovo\\IdeaProjects\\RestfulDemo\\src\\main\\java\\springboot\\d.txt");
            if (file.isFile() && file.exists()) {
                InputStreamReader isr = new InputStreamReader(new FileInputStream(file), "UTF-8");
                BufferedReader br = new BufferedReader(isr);
                String lineTxt = null;
                while ((lineTxt = br.readLine()) != null) {
                    dic.add(lineTxt.split(" ")[0]);
                }
                br.close();
            } else {
                System.out.println("Dictionary file doesn't exist!");
                return true;
            }
        } catch (Exception e) {
            System.out.println("Dictionary file reading error!");
            return true;
        }
        return false;
    }
    public boolean checkValid(HashSet<String> dic, String start, String end) {
        if (start == null || end == null || start.length() == 0 || end.length() == 0) {
            System.out.println("Illegal lengths!");
            return false;
        }
        if (!(dic.contains(start) && dic.contains(end))) {
            System.out.println("Unknown words!");
            return false;
        }
        if (start.equals(end)) {
            System.out.println("Identical words!");
            return false;
        }
        return true;
    }
    public void copy(LinkedList<String> from, LinkedList<String> to) {
        for (int i = 0; i < from.size(); ++i) {
            to.add(from.get(i));
        }
    }
    public String print(LinkedList<String> ladder) {
        String ret = "";
        for (int i = 0; i < ladder.size() - 1; ++i) {
            ret += ladder.get(i) + " -> ";
        }
        ret += ladder.getLast();
        return ret;
    }
    public List<String> neighbors(String word, HashSet<String> dic) {
        List<String> nei = new ArrayList<String>();
        String temp = null;
        int len = word.length();
        for (int i = 0; i < len; ++i) {
            word.substring(0, i);
            word.substring(i, len);
            for (char c = 'a'; c <= 'z'; ++c) {
                //change single letter
                if (c == word.charAt(i))
                    continue;
                char[] array = word.toCharArray();
                array[i] = c;
                temp = new String(array);
                if (dic.contains(temp))
                    nei.add(temp);
            }
        }
        return nei;
    }
    public String generate(HashSet<String> dic, String start, String end) {
        LinkedList<LinkedList<String>> ladders = new LinkedList<LinkedList<String>>();
        LinkedList<String> ladder = new LinkedList<String>();
        ladder.add(start);
        ladders.add(ladder);
        dic.remove(start);
        while (!ladders.isEmpty()) {
            ladder = ladders.poll();
            for (String neighbor : neighbors(ladder.getLast(), dic)) {
                ladder.add(neighbor);
                if (neighbor.equals(end)) {
                    return print(ladder);

                } else {
                    dic.remove(neighbor);
                    LinkedList<String> copyLadder = new LinkedList<String>();
                    copy(ladder, copyLadder);
                    ladders.add(copyLadder);
                }
                ladder.remove(neighbor);
            }
        }
        return "No ladder found between " + start + " and " + end + ".";
    }
    public String ladder(String begin,String end){
        HashSet<String> dic = new HashSet<String>();
        if (setUpDic(dic))
            return "No dictionary";
        if (!checkValid(dic, begin, end))
            return "Invalid words";
        return generate(dic, begin,end);
    }
}