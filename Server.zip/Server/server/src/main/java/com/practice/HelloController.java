package com.practice;

import java.util.concurrent.atomic.AtomicLong;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloController {
    private final AtomicLong counter = new AtomicLong();
    @RequestMapping("/hello")
    public Hello Hello(@RequestParam(value="begin", defaultValue="today") String begin,
                       @RequestParam(value="end", defaultValue="class") String end) {
        return new Hello(counter.incrementAndGet(),
                begin,end);
    }
}